<?php
/**
 * Plugin Name: Rename Block Names in List View
 * Plugin URI: https://yourwebsite.com/rename-block-names
 * Description: This plugin allows renaming block names in the List View of the WordPress Block Editor.
 * Version: 1.0
 * Author: Josh Liston
 * Author URI: https://tri.be
 * License: GPL2
 */

// Begin

function rename_block_names_enqueue_assets() {
    wp_enqueue_script(
        'rename-block-names-js',
        plugin_dir_url(__FILE__) . 'rename-block-names.js',
        array('wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data'),
        filemtime(plugin_dir_path(__FILE__) . 'rename-block-names.js')
    );
    wp_localize_script('rename-block-names-js', 'rbnPluginSettings', array(
        'customBlockNames' => get_option('rename_block_names', array()),
    ));
}
add_action('enqueue_block_editor_assets', 'rename_block_names_enqueue_assets');

function rename_block_names_update_block_name($attributes, $block_type) {
    if (isset($attributes['customBlockName'])) {
        $custom_block_names = get_option('rename_block_names', array());
        $custom_block_names[$block_type] = $attributes['customBlockName'];
        update_option('rename_block_names', $custom_block_names);
    }
    return $attributes;
}
add_filter('blocks_register_block_type', 'rename_block_names_add_block_name_field', 10, 2);

function rename_block_names_add_block_name_field($block_type, $args) {
    $args['attributes']['customBlockName'] = array(
        'type' => 'string',
    );
    return $args;
}

function rename_block_names_add_custom_block_name_to_block_html($block_content, $block) {
    $custom_block_names = get_option('rename_block_names', array());
    $block_type = $block['blockName'];
    $custom_block_name = isset($custom_block_names[$block_type]) ? $custom_block_names[$block_type] : null;
    if ($custom_block_name) {
        $block_content = str_replace('> ' . $block['title'], "> $custom_block_name", $block_content);
    }
    return $block_content;
}
add_filter('render_block', 'rename_block_names_add_custom_block_name_to_block_html', 10, 2);
