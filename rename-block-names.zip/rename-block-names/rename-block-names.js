(function (wp) {
  const { createElement } = wp.element;
  const { registerPlugin } = wp.plugins;
  const { PluginBlockSettingsMenuItem } = wp.editPost;
  const { withSelect, withDispatch } = wp.data;
  const { createHigherOrderComponent } = wp.compose;
  const { BlockNavigationLeaf } = wp.blockEditor;

  const RenameBlockMenuItem = (props) => {
    const {
      block,
      onUpdateBlockAttributes,
    } = props;

    const handleRenameClick = () => {
      console.log('handleRenameClick');
      const newBlockName = prompt('Name this section:', block.attributes.customBlockName || '');
      console.log('newBlockName:', newBlockName);
      if (newBlockName !== null) {
        onUpdateBlockAttributes(block.clientId, { customBlockName: newBlockName });
        console.log('updated attributes:', { customBlockName: newBlockName });
        const blockTitleSpan = document.querySelector(`[data-block="${block.clientId}"] .components-truncate`);
        if (blockTitleSpan) {
          blockTitleSpan.textContent = newBlockName;
        }
      }
    };

    return createElement(
      PluginBlockSettingsMenuItem,
      {
        allowedBlocks: true,
        icon: null,
        label: 'Rename',
        onClick: handleRenameClick,
      }
    );
  };

  const RenameBlockMenuItemWithData = withSelect((select) => {
    return {
      block: select('core/block-editor').getSelectedBlock(),
    };
  })(withDispatch((dispatch) => {
    return {
      onUpdateBlockAttributes: dispatch('core/block-editor').updateBlockAttributes,
    };
  })(RenameBlockMenuItem));

  registerPlugin('rename-block-names', {
    render: RenameBlockMenuItemWithData,
  });

  const withCustomBlockName = createHigherOrderComponent((BlockNavigationLeafComponent) => {
    return (props) => {
      console.log('withCustomBlockName props:', props);
      const { block } = props;
      const customBlockName = block.attributes.customBlockName || block.name;

      return createElement(
        'div',
        { style: { position: 'relative' } },
        createElement(BlockNavigationLeafComponent, props),
        customBlockName && createElement(
          'span',
          {
            style: {
              position: 'absolute',
              left: 0,
              top: 0,
              background: 'white',
              paddingLeft: 3,
              paddingRight: 3,
            },
          },
          customBlockName
        )
      );
    };
  }, 'withCustomBlockName');

  wp.hooks.addFilter(
    'editor.BlockNavigationLeaf',
    'rename-block-names/with-custom-block-name',
    withCustomBlockName
  );

})(window.wp);
